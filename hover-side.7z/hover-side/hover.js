const left=document.querySelector(".left");
const right=document.querySelector(".right");
const container=document.querySelector(".container");


left.addEventListener("mouseenter",()=>
 container.classList.add("hover-left") 
);


left.addEventListener("mouseleave",()=>
 container.classList.remove("hover-left") 
);



right.addEventListener("mouseenter",()=>
 container.classList.add("hover-right") 
);


right.addEventListener("mouseleave",()=>
 container.classList.remove("hover-right") 
);

// me://resources/roboto/roboto-regular.woff2

var col=5;
var rows=5;
var grid=new Array(col);
console.log("hello world");
console.log(col);
// function setup(){
    // createCanvas(400,400);
    // console.warn('A*');

    // for(var i=0; i<col;i++){
    //     grid[i]=new Array(rows);
 
    // }
    // console.warn(grid);
// }